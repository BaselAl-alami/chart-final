import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngx-admin-charts',
  templateUrl: './ngx-admin-charts.component.html',
  styleUrls: ['./ngx-admin-charts.component.css']
})
export class NgxAdminChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
