import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-high-charts',
  templateUrl: './high-charts.component.html',
  styleUrls: ['./high-charts.component.css']
})
export class HighChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
